会替换PopCap图标在加载游戏时显示，全称为Bloom & Doom Publishing Assoc.

由B站@马斯提夫 当初为TV触控版专属难度宣传片所制作的一份虚构的B&D出版协会的分级图示。